This is an example configuration for the CL-260 Ultimaker 2 clone.
Change Z_MAX_POS to 300 for the CL-260MAX.

(The printer is available on AliExpress; be aware that this is not a beginner's
printer -- it needs tweaking and some parts replaced before being decent.)

The printer comes with a quite old Marlin, the sources are available here:
http://www.thingiverse.com/thing:1635830/ and I recommend replacing them.

The setting "works" for my printer and the extruder using my calibration value.
You might want to tweak some settings, e.g enable EEPROM, increase default Z speed, adjust homing speeds,...

Have fun!
--
tobi
